-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.24-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.2.0.6576
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for job_posts
CREATE DATABASE IF NOT EXISTS `job_posts` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `job_posts`;

-- Dumping structure for table job_posts.mytable
CREATE TABLE IF NOT EXISTS `mytable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `work_experiences` text DEFAULT NULL,
  `skills` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table job_posts.mytable: ~0 rows (approximately)

-- Dumping structure for table job_posts.posts
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `heading` text NOT NULL,
  `img_location` text NOT NULL,
  `post_description` text NOT NULL,
  `post_tags` text NOT NULL,
  `likes` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `tb_post_like_info_id` int(11) DEFAULT NULL,
  `author` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table job_posts.posts: ~2 rows (approximately)
INSERT IGNORE INTO `posts` (`id`, `heading`, `img_location`, `post_description`, `post_tags`, `likes`, `deleted`, `tb_post_like_info_id`, `author`) VALUES
	(1, 'Looking for a web designer...', 'images/ggg.webp', 'Looking for a web designer to work for 24 hours.', 'UI/UX designer, UI/UX designer, UI/UX designer', 1, 0, 1, 'Charles Abdulwahab'),
	(2, 'Looking for a web designer...', 'images/ggg.webp', 'Looking for a web designer to work for 24 hours.', 'UI/UX designer, UI/UX designer, UI/UX designer', 1, 0, 2, 'Charles Abdulwahab');

-- Dumping structure for table job_posts.post_like_info
CREATE TABLE IF NOT EXISTS `post_like_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_stamp` text NOT NULL,
  `post_id` int(11) NOT NULL,
  `likes_count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table job_posts.post_like_info: ~0 rows (approximately)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
